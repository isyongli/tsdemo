function watch() {
    // TODO
}

window.watch = watch;